#include "ab.h"
int main()
{
 printf("First Nice \n");
 system("ps -l");
 nice(10);
 system("ps -l");
 printf("End");
}
