#include<stdio.h>
#include<unistd.h>
int main()
{
  printf("Hello");
  system("date");
}
