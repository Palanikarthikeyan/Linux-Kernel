#include "ab.h"
#include<sys/wait.h>
int main()
{
  int status;
  if(fork())
  {
      wait(&status);
      printf("Parent PID=%d,Child",getpid());
      printf("Exit status=%d\n",WEXITSTATUS(status));
  }
  else{
	printf("Child PID=%d\n",getpid());
	exit(55);
      }
}
