#include "ab.h"

	main(int argc, char **argv)
	{
		if (argc==1)
		{
			printf("Usage: run <command> [<paraneters>]\n"); 
			exit(1)
		}
		execv(argv[l], &argv[1)); 
		printf("Sorry...   couldn't run that!\n");
	}
