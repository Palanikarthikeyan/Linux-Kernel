#include "ab.h"

static volatile sig_atomic_t doneflag = 0;

int main (void) {
 struct sigaction act;

 act.sa_handler = setdoneflag;/* set up signal handler */
 act.sa_flags = 0;
 if ((sigemptyset(&act.sa_mask) == -1) ||
       (sigaction(SIGINT, &act, NULL) == -1)) {
     perror("Failed to set SIGINT handler");
     return 1;
 }

 while (!doneflag) {
     printf("press CTRL+C to kill the loop\n");
     sleep(1);
 }

 printf("Program terminating ...\n");
 return 0;
}
