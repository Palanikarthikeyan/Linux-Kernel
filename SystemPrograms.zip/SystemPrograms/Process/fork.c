#include<unistd.h>
#include<stdio.h>
int main()
{
  int pid;
  pid=fork(); 
  if(pid != 0){  
                 printf("I am child exit with:");
                 printf("%d\n",pid);
              }
 else{
		printf("I am parent exit with:");
                printf("%d\n",pid);
     }
}
