#include "ab.h"

int main()
{
  alarm(3);
  while(1){
		sleep(1);
}
}
