#include "ab.h"

int main()
{
  alarm(5);
  while(1){
	system("vmstat >Result.log");
}
}
