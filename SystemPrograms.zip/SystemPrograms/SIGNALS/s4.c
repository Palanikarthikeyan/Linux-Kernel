#include "ab.h"
int main()
{
  
 printf("I can be Ctrl'd \n");
 signal(SIGINT,SIG_IGN);
 while(1){ 
   sleep(1);
 }
}
