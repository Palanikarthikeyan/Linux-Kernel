#include "ab.h"
int Hello(){
	printf("Hello thread\n");
}

int main(){
	pthread_t tid;
	printf("B4 Call\n");
	pthread_create(&tid,NULL,Hello,NULL);
	printf("After call\n");
	pthread_exit(NULL);
	return 0;
}
