#include "ab.h"

int *Hello(int i)
{
	int sum=0;
	printf("Hello:%x\n",pthread_self());
	printf("Hello thread..\n");
        for(i=0;i<5;i++)
	{
		sum=10+5;
	}	
	printf("Total:%d\n",sum);
	pthread_exit(NULL);
}
int main()
{
	pthread_t tid;
	int t,i,total;
	for(i=0;i<5;i++)
	{
		total=pthread_create(&tid,NULL,Hello,i);

	}
	printf("MainID:%x\n",pthread_self());
	pthread_join(&tid,NULL);
//	pthread_exit(NULL);
}

