#include "ab.h"

int Hello(void)
{
	printf("Hello1..");
}

int main()
{
	pthread_t  tid;
	pthread_create(&tid,NULL,Hello,NULL);
//	pthread_join(tid,NULL);
	printf("I am main..\n");
//	pthread_exit(NULL);
	return 0;
}
