#include "ab.h"

#define MSGSZ 128

struct s_name{
   char name;
   int id;
};

int main()
{
  struct s_name sv;
  sv.name="Kumar";
  sv.id=101;
  int msgqid;
  key_t key;
  key=ftok(".",'e');
  msgqid=msgget(key,IPC_CREAT|0666);
  msgsnd(msgqid,&sv,sizeof(struct s_name),0);
  return 0;
}
  
  
